"""
One chroma collection per chunking strategy... so that strategies can be compared side to side.

Each collection remembers a "fingerprint" of the chunks and the embedding model that built it.
If either changes, the collection is rebuilt from scratch. 
"""

# Things to note from our switch to chroma

# embed_texts is imported not rewritten... embedding provider hasnt changed... only the storage has
# configuration=.... -> not optional, we are choosing something different from chromas default
# chroma return distance, we return similarity
# in chroma, lower is better
# higher was better for ours.... (1 -  distance) converts
# upsert instead of add -> add fails on an id that already exists, upsert overwrites p


import hashlib
import chromadb

import chunking
import knowledge
from corpus import CORPUS_DOCUMENTS
from documents import DOCUMENTS

ALL_DOCS = DOCUMENTS + CORPUS_DOCUMENTS

BATCH_SIZE = 128 # Voyage's own guidance: batch documents to stay well inside rate limits

chroma = chromadb.PersistentClient(path="./chroma_store")


def collection_name(strategy: str) -> str:
    return f"chunks_{strategy}"


def collection_for(strategy: str):
    return chroma.get_or_create_collection(
        name=collection_name(strategy),
        configuration={"hnsw": {"space": "cosine"}}
    )

def embed_batched(texts: list[str], input_type: str) -> tuple[list[list[float]], int]:
    """Embed any number of texts in batches. Return all vectors and the total token count. """
    vectors: list[list[float]] = []
    tokens = 0

    for start in range(0, len(texts), BATCH_SIZE):
        batch_vectors, batch_tokens = knowledge.embed_texts(texts[start:start+BATCH_SIZE], input_type=input_type)
        vectors.extend(batch_vectors)
        tokens += batch_tokens
    return vectors, tokens


# The fingerprint changes if the text, the model or the order changes... and stays put of nothing does. 
def fingerprint(chunks: list[dict]) -> str:
    # SHA-256 - A recipe that turns any text into a fixed-legth code (64 chars)
    digest = hashlib.sha256(knowledge.EMBED_MODEL.encode())
    for c in chunks:
        digest.update(f"{c['id']}\n{c['text']}\n".encode())
    return digest.hexdigest()[:16]  # first 16 chars is enough to detect changes



def build(strategy: str, force: bool = False) -> dict:
    """Make sure the strategy's collection matches the current corpus, chunker and model."""
    """ Answers one q... is the index i already have still correct?"""
    # pt1
    chunks = chunking.chunk_corpus(ALL_DOCS, strategy)
    fp = fingerprint(chunks)
    col = collection_for(strategy) 
    stored = col.get(limit=1, include=["metadatas"])["metadatas"]
    if not force and col.count() == len(chunks) and stored and stored[0].get("fingerprint") == fp:
        return {"strategy": strategy,"chunks": len(chunks), "embedding_tokens": 0, "rebuilt": False}
    
    # pt 2 - the rebuild
    try:
        chroma.delete_collection(name=collection_name(strategy))
    except Exception:
        pass

    col = collection_for(strategy)
    vectors, tokens = embed_batched([c["text"] for c in chunks], input_type="document")
    col.upsert(
        ids=[c["id"] for c in chunks],
        embeddings=vectors,
        documents=[c["text"] for c in chunks],
        metadatas=[{"doc_id": c["doc_id"], "title": c["title"], "fingerprint": fp} for c in chunks]
    )
    return {"strategy": strategy,"chunks": len(chunks), "embedding_tokens": tokens, "rebuilt": True}
# the vectors come back in the voyage the same way they went in, so you can just extend a list with them.
# at the moment were able to population each of the collections 

# CURRENT 

# NEW FUNCTION ADDS - search_with_vectors
# the read side
# it takes question vectors that are already embedded, so questions are embedded once and resused across all 6 categories

def search_with_vectors(strategy: str, query_vectors: list[list[float]], k: int) -> list[list[dict]]:
    """
    we embed the question once, then searches many strategies with the same vectors.
    """
    col = collection_for(strategy)
    if col.count() == 0:
        raise RuntimeError(f"Index for '{strategy}' is empty. Please build it first.")
    
    # the search
    results = col.query(query_embeddings=query_vectors, n_results=min(k, col.count()))
    # what result looks like 
        # - result["ids"] - a list of 2 lists, each holding 3 ids
        # - result["documents"] - a list of 2 lists, each holding 3 texts
        # - result["metadatas"] - a list of 2 lists, each holding 3 metadata dictionaries
        # - result["distances"] - a list of 2 lists, each holding 3 distances 
        # - e.g. ids          [ 'doc-001#00', 'doc-001#01', 'doc-007#00' ]
        # - e.g. documents    [0.375, 0.389, 0.30
    return[
        # chroma returns 4 parallel nested lists
        [
            {
                "id": meta["doc_id"], "chunk_id": chunk_id, "title": meta["title"], "text": text, "score": 1 - distance}
                for chunk_id, text, meta, distance in zip(ids, docs, metas, dists)
            
        ]
        for ids, docs, metas, dists in zip(
            results["ids"], results["documents"], results["metadatas"], results["distances"]
        )
        # Chroma returns
    ]


"""
a chunk that only keyword search found has npo cosine score... our relevant gate needs one
"""

def cosine_for(strategy: str, query_vector: list[float], chunk_ids: list[str]) -> dict[str, float]:
    if not chunk_ids:
        return {}
    
    stored = collection_for(strategy).get(ids=chunk_ids, include=["embeddings", "metadatas"])

    return {
        chunk_id: float(knowledge.cosine_similarity(query_vector, list(vector)))
        for chunk_id, vector in zip(stored["ids"], stored["embeddings"])
    }

# where it fits in hybrid.py
    # vector search returns its top 10 with cosine
    # keyword search returns its top 10 
    # RRF merges them
    # any chunk in the keyword list but NOT in the vector list is passed to "cosine_for"
        # score >= 0.45 orrrr exact_match

# question mentions 3307
# chunk mentions 3307